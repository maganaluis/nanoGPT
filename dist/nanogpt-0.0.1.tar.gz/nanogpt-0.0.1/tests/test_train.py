def import_test():
    import nanogpt